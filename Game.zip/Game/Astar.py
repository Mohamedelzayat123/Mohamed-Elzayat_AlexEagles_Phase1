from pyamaze import maze, agent, COLOR, textLabel
import heapq

def heuristic(a, b):
    # Manhattan distance heuristic for a grid
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def a_star(m, *hurdles, start=None):
    if start is None:
        start = (m.rows, m.cols)

    goal = m._goal
    hurdles = {(i.position, i.cost) for i in hurdles}

    # Priority queue to explore the most promising nodes first
    open_set = []
    heapq.heappush(open_set, (0, start))  # (f(n), node)
    
    came_from = {}  # To reconstruct the path later
    g_score = {state: float('inf') for state in m.grid}
    g_score[start] = 0
    
    f_score = {state: float('inf') for state in m.grid}
    f_score[start] = heuristic(start, goal)

    while open_set:
        # Get the node in the open set with the lowest f_score value
        current = heapq.heappop(open_set)[1]

        if current == goal:
            # Reconstruct the path from start to goal
            path = {}
            while current in came_from:
                prev = came_from[current]
                path[prev] = current
                current = prev
            return path, g_score[goal]

        for direction in 'EWNS':
            if m.maze_map[current][direction]:
                if direction == 'E':
                    neighbor = (current[0], current[1] + 1)
                elif direction == 'W':
                    neighbor = (current[0], current[1] - 1)
                elif direction == 'S':
                    neighbor = (current[0] + 1, current[1])
                elif direction == 'N':
                    neighbor = (current[0] - 1, current[1])

                # Tentative g_score
                tentative_g_score = g_score[current] + 1  # Default movement cost is 1

                # Add hurdle cost if there is any
                for hurdle in hurdles:
                    if hurdle[0] == neighbor:
                        tentative_g_score += hurdle[1]

                if tentative_g_score < g_score[neighbor]:
                    # This path to neighbor is better than any previous one
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

    return None, float('inf')  # If there's no path to the goal


if __name__ == '__main__':
    myMaze = maze(10, 15)
    myMaze.CreateMaze(1, 4, loopPercent=100)

    # Define hurdles with costs
    h1 = agent(myMaze, 4, 4, color=COLOR.red)
    h2 = agent(myMaze, 4, 6, color=COLOR.red)
    h3 = agent(myMaze, 4, 1, color=COLOR.red)
    h4 = agent(myMaze, 4, 2, color=COLOR.red)
    h5 = agent(myMaze, 4, 3, color=COLOR.red)

    # Set costs for hurdles
    h1.cost = 100
    h2.cost = 100
    h3.cost = 100
    h4.cost = 100
    h5.cost = 100

    
    # A* algorithm instead of policy iteration
    path, cost = a_star(myMaze, h1, h2, h3, h4, h5, start=(6, 1))
    
 

    # Add text labels to show important information
    textLabel(myMaze, 'Total Cost', cost)

    textLabel(myMaze, 'Goal state', myMaze._goal)

    # Trace the path on the maze
    a = agent(myMaze, 6, 1, color=COLOR.cyan, filled=True, footprints=True)
    myMaze.tracePath({a: path})

    # Run the maze animation
    myMaze.run()

    # Print the result details
    print("Cost of the path:", cost)
    print("Path to the goal:", path)
    print("Initial state:", (6, 1))
    print("Goal state:", myMaze._goal)
 