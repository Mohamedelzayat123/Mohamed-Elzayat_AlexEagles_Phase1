from pyamaze import maze,agent,COLOR,textLabel
def policyIteration(m, *h, start=None):
    if start is None:
        start = (m.rows, m.cols)

    hurdles = {(i.position, i.cost) for i in h}

    policy = {}  # A dictionary to store the optimal actions for each state
    values = {n: float('inf') for n in m.grid}  # A dictionary to store the values (distances) for each state
    values[m._goal] = -100 # The goal state has a value of 0

    while True:
        # Policy Evaluation
        while True:
            delta = 0
            for state in m.grid:
                if state == m._goal:
                    continue

                old_value = values[state]
                best_value = float('inf')

                for d in 'EWNS':
                    if m.maze_map[state][d]:
                        if d == 'E':
                            next_state = (state[0], state[1] + 1)
                        elif d == 'W':
                            next_state = (state[0], state[1] - 1)
                        elif d == 'S':
                            next_state = (state[0] + 1, state[1])
                        elif d == 'N':
                            next_state = (state[0] - 1, state[1])

                        temp_value = 1  # Cost of moving to the next state

                        for hurdle in hurdles:
                            if hurdle[0] == state:
                                temp_value += hurdle[1]

                        temp_value += values[next_state]

                        if temp_value < best_value:
                            best_value = temp_value

                values[state] = best_value
                delta = max(delta, abs(old_value - values[state]))

            if delta < 1e-6:
                break

        # Policy Improvement
        policy_stable = True
        for state in m.grid:
            if state == m._goal:
                continue

            old_action = policy.get(state, None)
            best_action = None
            best_value = float('inf')

            for d in 'EWNS':
                if m.maze_map[state][d]:
                    if d == 'E':
                        next_state = (state[0], state[1] + 1)
                    elif d == 'W':
                        next_state = (state[0], state[1] - 1)
                    elif d == 'S':
                        next_state = (state[0] + 1, state[1])
                    elif d == 'N':
                        next_state = (state[0] - 1, state[1])

                    temp_value = 1  # Cost of moving to the next state

                    for hurdle in hurdles:
                        if hurdle[0] == state:
                            temp_value += hurdle[1]

                    temp_value += values[next_state]

                    if temp_value < best_value:
                        best_value = temp_value
                        best_action = d

            policy[state] = best_action
            if old_action != best_action:
                policy_stable = False

        if policy_stable:
            break

    # Construct the forward path from the start state to the goal state using the optimal policy
    fwdPath = {}
    state = start
    while state != m._goal:
        action = policy[state]
        if action == 'E':
            next_state = (state[0], state[1] + 1)
        elif action == 'W':
            next_state = (state[0], state[1] - 1)
        elif action == 'S':
            next_state = (state[0] + 1, state[1])
        elif action == 'N':
            next_state = (state[0] - 1, state[1])

        fwdPath[state] = next_state
        state = next_state

    return fwdPath, values[m._goal]  # Return path and distance traveled to the goal




import time

if __name__=='__main__':
    goalX=0
    goalY=0
    x=int(input("please enter the size of the maze?: "))
    myMaze=maze(x,x)
    while(goalX>x or goalX<=0 ):
        goalX=int(input("please enter the row number for the goal state?: "))
    while(goalY>x or goalY<=0):
        goalY=int(input("please enter the column number for the goal state?: "))
    myMaze.CreateMaze(goalX,goalY,loopPercent=100)


    h1=agent(myMaze,4,4,color=COLOR.red)
    h2=agent(myMaze,4,5,color=COLOR.red)
    h3=agent(myMaze,4,1,color=COLOR.red)
    h4=agent(myMaze,4,2,color=COLOR.red)
    h5=agent(myMaze,4,3,color=COLOR.red)

    h1.cost=50
    h2.cost=50
    h3.cost=50
    h4.cost=50
    h5.cost=50
    xI=0
    yI=0
    while (xI<=0 or xI>x):
        xI=int(input("Enter the row num. of the initial state?:"))
    while (yI<=0 or yI>x):
        yI=int(input("Enter the column num. of the initial state?:"))
    start_time = time.time()
    path, c = policyIteration(myMaze, h1, h2, h3, h4, h5, start=(xI,yI))
    end_time = time.time()
    
    textLabel(myMaze, 'Total Cost',abs(len(path)-100))
    textLabel(myMaze, 'running time:', end_time - start_time)
    textLabel(myMaze, 'goal state ',myMaze._goal)

    a=agent(myMaze,xI,yI,color=COLOR.cyan,filled=True,footprints=True)
    myMaze.tracePath({a:path})

    myMaze.run()

    print("Cost of the path:", abs(len(path)-100))
    print("Path to the goal:", path)
    print("Initial state:", (6, 1))
    print("Goal state:", myMaze._goal)
    print("Running time:", end_time - start_time, "seconds")