from pyamaze import maze, agent, COLOR, textLabel
import time

def valueIteration(m, *h, start=None):
    if start is None:
        start = (m.rows, m.cols)

    hurdles = {(i.position, i.cost) for i in h}

    values = {n: float('inf') for n in m.grid}  # A dictionary to store the values (distances) for each state
    values[m._goal] = -100  # The goal state has a value of 0

    while True:
        delta = 0

        for state in m.grid:
            if state == m._goal:
                continue

            old_value = values[state]
            best_value = float('inf')

            for d in 'EWNS':
                if m.maze_map[state][d]:
                    if d == 'E':
                        next_state = (state[0], state[1] + 1)
                    elif d == 'W':
                        next_state = (state[0], state[1] - 1)
                    elif d == 'S':
                        next_state = (state[0] + 1, state[1])
                    elif d == 'N':
                        next_state = (state[0] - 1, state[1])

                    temp_value = 1  # Cost of moving to the next state

                    for hurdle in hurdles:
                        if hurdle[0] == state:
                            temp_value += hurdle[1]

                    temp_value += values[next_state]

                    if temp_value < best_value:
                        best_value = temp_value

            values[state] = best_value
            delta = max(delta, abs(old_value - values[state]))

        if delta < 1e-6:
            break

    # Policy Improvement
    policy = {}
    for state in m.grid:
        if state == m._goal:
            continue

        best_action = None
        best_value = float('inf')

        for d in 'EWNS':
            if m.maze_map[state][d]:
                if d == 'E':
                    next_state = (state[0], state[1] + 1)
                elif d == 'W':
                    next_state = (state[0], state[1] - 1)
                elif d == 'S':
                    next_state = (state[0] + 1, state[1])
                elif d == 'N':
                    next_state = (state[0] - 1, state[1])

                temp_value = 1  # Cost of moving to the next state

                for hurdle in hurdles:
                    if hurdle[0] == state:
                        temp_value += hurdle[1]

                temp_value += values[next_state]

                if temp_value < best_value:
                    best_value = temp_value
                    best_action = d

        policy[state] = best_action

    # Construct the forward path from the start state to the goal state using the optimal policy
    fwdPath = {}
    state = start
    while state != m._goal:
        action = policy[state]
        if action == 'E':
            next_state = (state[0], state[1] + 1)
        elif action == 'W':
            next_state = (state[0], state[1] - 1)
        elif action == 'S':
            next_state = (state[0] + 1, state[1])
        elif action == 'N':
            next_state = (state[0] - 1, state[1])

        fwdPath[state] = next_state
        state = next_state

    return fwdPath, values[m._goal]  # Return path and distance traveled to the goal

if __name__ == '__main__':
    myMaze = maze(10, 15)
    myMaze.CreateMaze(1, 4, loopPercent=100)

    h1 = agent(myMaze, 4, 4, color=COLOR.red)
    h2 = agent(myMaze, 4, 6, color=COLOR.red)
    h3 = agent(myMaze, 4, 1, color=COLOR.red)
    h4 = agent(myMaze, 4, 2, color=COLOR.red)
    h5 = agent(myMaze, 4, 3, color=COLOR.red)

    h1.cost = 100
    h2.cost = 100
    h3.cost = 100
    h4.cost = 100
    h5.cost = 100

    start_time = time.time()
    path, c = valueIteration(myMaze, h1, h2, h3, h4, h5, start=(6, 1))
    end_time = time.time()

    textLabel(myMaze, 'Total Cost',abs(len(path)-100))
    textLabel(myMaze, 'Running time:', end_time - start_time)
    textLabel(myMaze, 'goal state:', myMaze._goal)
    a = agent(myMaze, 6, 1, color=COLOR.cyan, filled=True, footprints=True)
    myMaze.tracePath({a: path})

    myMaze.run()

    print("Cost of the path:", abs(len(path)-100))
    print("Path to the goal:", path)
    print("Initial state:", (6, 1))
    print("Goal state:", myMaze._goal)
    print("Running time:", end_time - start_time, "seconds")