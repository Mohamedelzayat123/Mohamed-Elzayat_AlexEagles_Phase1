from models.flight import Flight
from models.airport import Airport
from models.customer import Customer

class FlightBookingSystem:
    def __init__(self):
        self.flights = []
        self.airports = []
        self.bookings = []

    def add_flight(self, flight):
        self.flights.append(flight)

    def add_airport(self, airport):
        self.airports.append(airport)

    def get_all_flights(self):
        return self.flights

    def get_all_airports(self):
        return self.airports

    def find_flight(self, flight_number):
        for flight in self.flights:
            if flight.flight_number == flight_number:
                return flight
        return None

    def get_airport_by_code(self, code):
        for airport in self.airports:
            if airport.code == code:
                return airport
        return None

    def book_flight(self, customer, flight):
        booking = {
            'customer': customer,
            'flight': flight
        }
        self.bookings.append(booking)
        return booking
