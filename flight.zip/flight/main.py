import tkinter as tk
from tkinter import ttk, messagebox
from models.flight import Flight
from models.airport import Airport
from models.service import Service
from models.customer import Customer
from models.flight_search import FlightSearch
from booking_system import FlightBookingSystem

class FlightBookingApp:
    def __init__(self, root, system):
        self.root = root
        self.system = system
        self.root.title("Flight Booking System")
        self.root.geometry("1000x900")
        self.root.configure(bg="#f0f8ff")

        # Title Label
        title_label = tk.Label(
            root,
            text="Flight Booking System",
            font=("Helvetica", 24, "bold"),
            bg="#f0f8ff",
            fg="#333"
        )
        title_label.pack(pady=20)

        # Search Frame
        search_frame = tk.Frame(root, bg="#f0f8ff")
        search_frame.pack(pady=10)

        # Departure Airport
        departure_label = tk.Label(
            search_frame,
            text="Departure Airport:",
            font=("Helvetica", 14),
            bg="#f0f8ff"
        )
        departure_label.grid(row=0, column=0, padx=10, pady=5, sticky="e")

        self.departure_var = tk.StringVar()
        self.departure_combo = ttk.Combobox(
            search_frame,
            textvariable=self.departure_var,
            font=("Helvetica", 12),
            width=25,
            values=self.get_airport_codes()
        )
        self.departure_combo.grid(row=0, column=1, padx=10, pady=5)

        # Arrival Airport
        arrival_label = tk.Label(
            search_frame,
            text="Arrival Airport:",
            font=("Helvetica", 14),
            bg="#f0f8ff"
        )
        arrival_label.grid(row=1, column=0, padx=10, pady=5, sticky="e")

        self.arrival_var = tk.StringVar()
        self.arrival_combo = ttk.Combobox(
            search_frame,
            textvariable=self.arrival_var,
            font=("Helvetica", 12),
            width=25,
            values=self.get_airport_codes()
        )
        self.arrival_combo.grid(row=1, column=1, padx=10, pady=5)

        # Search Button
        search_button = tk.Button(
            search_frame,
            text="Search Flights",
            font=("Helvetica", 14),
            bg="#4CAF50",
            fg="white",
            width=15,
            command=self.search_flights
        )
        search_button.grid(row=2, column=0, columnspan=2, pady=15)

        # Results Frame
        results_frame = tk.Frame(root, bg="#f0f8ff")
        results_frame.pack(pady=10)

        results_label = tk.Label(
            results_frame,
            text="Available Flights:",
            font=("Helvetica", 16, "bold"),
            bg="#f0f8ff"
        )
        results_label.pack(anchor="w", padx=10)

        # Flights Listbox
        self.flights_listbox = tk.Listbox(
            results_frame,
            font=("Helvetica", 12),
            width=80,
            height=8
        )
        self.flights_listbox.pack(padx=10, pady=5)

        # User Details Frame
        user_frame = tk.Frame(root, bg="#f0f8ff")
        user_frame.pack(pady=10)

        user_details_label = tk.Label(
            user_frame,
            text="Customer Details:",
            font=("Helvetica", 16, "bold"),
            bg="#f0f8ff"
        )
        user_details_label.grid(row=0, column=0, columnspan=2, pady=10)

        # Name
        name_label = tk.Label(
            user_frame,
            text="Full Name:",
            font=("Helvetica", 14),
            bg="#f0f8ff"
        )
        name_label.grid(row=1, column=0, padx=10, pady=5, sticky="e")

        self.name_var = tk.StringVar()
        name_entry = tk.Entry(
            user_frame,
            textvariable=self.name_var,
            font=("Helvetica", 12),
            width=30
        )
        name_entry.grid(row=1, column=1, padx=10, pady=5)

        # Phone Number
        phone_label = tk.Label(
            user_frame,
            text="Phone Number:",
            font=("Helvetica", 14),
            bg="#f0f8ff"
        )
        phone_label.grid(row=2, column=0, padx=10, pady=5, sticky="e")

        self.phone_var = tk.StringVar()
        phone_entry = tk.Entry(
            user_frame,
            textvariable=self.phone_var,
            font=("Helvetica", 12),
            width=30
        )
        phone_entry.grid(row=2, column=1, padx=10, pady=5)

        # Book Flight Button
        book_button = tk.Button(
            root,
            text="Book Flight",
            font=("Helvetica", 16),
            bg="#2196F3",
            fg="white",
            width=20,
            command=self.book_flight
        )
        book_button.pack(pady=20)
                # Email
        email_label = tk.Label(
            user_frame,
            text="Email:",
            font=("Helvetica", 14),
            bg="#f0f8ff"
        )
        email_label.grid(row=2, column=0, padx=10, pady=5, sticky="e")

        self.email_var = tk.StringVar()
        email_entry = tk.Entry(
            user_frame,
            textvariable=self.email_var,
            font=("Helvetica", 12),
            width=30
        )
        email_entry.grid(row=2, column=1, padx=10, pady=5)

        # Move Phone Number below Email
        phone_label.grid(row=3, column=0, padx=10, pady=5, sticky="e")
        phone_entry.grid(row=3, column=1, padx=10, pady=5)

        # Previous code...

    def validate_user_input(self):
        name = self.name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()

        if not name.isalpha():
            messagebox.showwarning("Input Error", "Name should only contain letters.")
            return False

        if not email or "@" not in email:
            messagebox.showwarning("Input Error", "Please enter a valid email address.")
            return False

        if not phone.isdigit() or len(phone) != 11:
            messagebox.showwarning("Input Error", "Phone number should be exactly 11 digits.")
            return False

        return True

    def book_flight(self):
        if not self.validate_user_input():
            return

        selected_index = self.flights_listbox.curselection()
        if not selected_index:
            messagebox.showwarning("Selection Error", "Please select a flight to book.")
            return

        selected_flight_info = self.flights_listbox.get(selected_index)
        flight_number = selected_flight_info.split('|')[0].strip()
        flight = self.system.find_flight(flight_number)

        if not flight:
            messagebox.showerror("Booking Error", "Selected flight not found.")
            return

        name = self.name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()

        customer = Customer(name, email, phone)
        booking = self.system.book_flight(customer, flight)

        if booking:
            messagebox.showinfo(
                "Booking Confirmed",
                f"Flight {flight.flight_number} booked successfully for {customer.name}.\nThank you for choosing our service!"
            )
            # Clear inputs
            self.name_var.set("")
            self.email_var.set("")
            self.phone_var.set("")
            self.flights_listbox.delete(0, tk.END)
        else:
            messagebox.showerror("Booking Error", "Failed to book the flight. Please try again.")

    def get_airport_codes(self):
        return list({airport.code for airport in self.system.get_all_airports()})

    def search_flights(self):
        departure_code = self.departure_var.get().strip()
        arrival_code = self.arrival_var.get().strip()

        if not departure_code or not arrival_code:
            messagebox.showwarning("Input Error", "Please select both departure and arrival airports.")
            return

        departure_airport = self.system.get_airport_by_code(departure_code)
        arrival_airport = self.system.get_airport_by_code(arrival_code)

        if not departure_airport or not arrival_airport:
            messagebox.showerror("Airport Error", "Selected airports are not available in the system.")
            return

        search = FlightSearch(self.system.get_all_flights())
        results = search.search_flights(departure_airport, arrival_airport)

        self.flights_listbox.delete(0, tk.END)

        if results:
            for flight in results:
                flight_info = f"{flight.flight_number} | {flight.airline} | {flight.departure_time} - {flight.arrival_time} | ${flight.price}"
                self.flights_listbox.insert(tk.END, flight_info)
        else:
            messagebox.showinfo("No Flights Found", "No flights available for the selected route.")





if __name__ == "__main__":
    system = FlightBookingSystem()

    # Sample Airports
    jfk = Airport("JFK", "John F. Kennedy International Airport", "New York")
    lax = Airport("LAX", "Los Angeles International Airport", "Los Angeles")
    sfo = Airport("SFO", "San Francisco International Airport", "San Francisco")
    ord = Airport("ORD", "O'Hare International Airport", "Chicago")

    # Add Airports to System
    system.add_airport(jfk)
    system.add_airport(lax)
    system.add_airport(sfo)
    system.add_airport(ord)

    # Add sample flights
    flight1 = Flight("AA101", "American Airlines", jfk, lax, "08:00 AM", "11:00 AM", 300)
    flight2 = Flight("DL202", "Delta Airlines", jfk, lax, "09:00 AM", "12:00 PM", 320)
    flight3 = Flight("UA303", "United Airlines", sfo, ord, "10:00 AM", "01:00 PM", 250)
    system.add_flight(flight1)
    system.add_flight(flight2)
    system.add_flight(flight3)

    # Add sample services
    meal_service = Service("Meal", 50)
    extra_baggage = Service("Extra Baggage", 100)
    flight1.add_service(meal_service)
    flight1.add_service(extra_baggage)
    flight2.add_service(meal_service)

    # Start the GUI
    root = tk.Tk()
    app = FlightBookingApp(root, system)
    root.mainloop()


