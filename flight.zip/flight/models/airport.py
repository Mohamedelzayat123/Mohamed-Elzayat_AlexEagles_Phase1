class Airport:
    def __init__(self, code, name, city):
        self.code = code
        self.name = name
        self.city = city

    def __str__(self):
        return f"{self.name} ({self.code}) - {self.city}"
