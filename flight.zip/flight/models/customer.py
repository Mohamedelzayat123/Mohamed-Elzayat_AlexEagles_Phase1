class Customer:
    def __init__(self, name, email, phone_number):
        self.name = name
        self.email = email
        self.phone_number = phone_number


    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.email} - {self.phone_number}"
