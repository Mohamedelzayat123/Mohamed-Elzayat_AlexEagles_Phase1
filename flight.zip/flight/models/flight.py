class Flight:
    def __init__(self, flight_number, airline, departure_airport, arrival_airport, departure_time, arrival_time, price):
        self.flight_number = flight_number
        self.airline = airline
        self.departure_airport = departure_airport
        self.arrival_airport = arrival_airport
        self.departure_time = departure_time
        self.arrival_time = arrival_time
        self.price = price
        self.services = []

    def add_service(self, service):
        self.services.append(service)

    def __str__(self):
        return f"Flight {self.flight_number} - {self.airline} from {self.departure_airport} to {self.arrival_airport} at {self.departure_time}"
