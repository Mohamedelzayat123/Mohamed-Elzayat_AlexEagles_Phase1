from .flight import Flight

class FlightSearch:
    def __init__(self, flights):
        self.flights = flights

    def search_flights(self, departure_airport, arrival_airport, max_price=None):
        filtered_flights = [
            flight for flight in self.flights
            if flight.departure_airport.code == departure_airport.code and flight.arrival_airport.code == arrival_airport.code
        ]
        if max_price:
            filtered_flights = [flight for flight in filtered_flights if flight.price <= max_price]
        return filtered_flights
